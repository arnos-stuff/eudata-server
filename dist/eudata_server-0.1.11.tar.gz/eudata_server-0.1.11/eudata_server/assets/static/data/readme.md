# source:

eurostat [data .dic format](https://ec.europa.eu/eurostat/estat-navtree-portlet-prod/BulkDownloadListing?sort=1&dir=dic%2Fen)

# convert to JSON

Use a regex substitution to convert the .dic files to JSON.
This [is what I used:](https://regex101.com/r/hXvHtM/1)