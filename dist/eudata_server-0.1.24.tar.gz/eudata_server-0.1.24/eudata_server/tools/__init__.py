from .paths import (
    package_dir, assets_dir, static_dir,
    templates_dir, css_dir, js_dir, sass_dir,
    data_dir
)
